console.log('Updating remote translations.');
console.log('Not yet implemented (TODO) -- no operation taken.');
