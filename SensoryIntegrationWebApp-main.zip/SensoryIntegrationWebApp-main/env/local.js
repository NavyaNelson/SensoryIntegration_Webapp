/* 
 * LOCAL CONFIG
 * This is intended for devs while working locally.
 */

const APP_URL = 'http://localhost:3000';

module.exports = {
  APP_URL,
  EXAMPLE_CONFIG: 'Local config',
};
