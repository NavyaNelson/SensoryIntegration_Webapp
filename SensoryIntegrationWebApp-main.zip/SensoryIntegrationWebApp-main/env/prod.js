/* 
 * PROD CONFIG
 * This is intended for deployment to a hosting service.
 */

const APP_URL = 'https://cboard.somehost.com';

module.exports = {
  APP_URL,
  EXAMPLE_CONFIG: 'Prod config',
};